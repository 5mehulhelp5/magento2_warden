<?php

/**
 * Copyright 2024 Adobe
 * All Rights Reserved.
 */

Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'RajNishad_Assignment4',
    __DIR__
);
